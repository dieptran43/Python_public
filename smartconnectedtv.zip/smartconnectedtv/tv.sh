#!/bin/bash
sudo sleep 5
sudo python $1/connectedTv.py >> /var/log/pi/tv.log 2>&1


