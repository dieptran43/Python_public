import time
print("ctv")
while True:
	print("My first success test")
	time.sleep(60)
