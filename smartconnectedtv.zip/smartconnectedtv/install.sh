#!/bin/bash
echo "installing python libraries"
pip install $1/pylibs/requests-2.12.4.tar.gz
pip install $1/pylibs/python-vlc-3.0.101.tar.gz
pip install $1/pylibs/pathlib-1.0.1.tar.gz
pip install $1/pylibs/paho-mqtt-1.5.0.tar.gz

mkdir -p /var/log/pi
chmod -R 777 /var/log/pi

echo "Stopping running startup service"
systemctl stop startup.service
sleep 5
echo "disabling startup sevice"
systemctl disable startup.service
sleep 5
echo "creating startup service"
echo "[Unit]
Description=ConnectedTv

[Service]
Type=idle
ExecStart=/bin/bash $1/tv.sh $1 >> /var/log/pi/tv.log 2>&1

[Install]
WantedBy=multi-user.target
" > startup.service
cp startup.service /etc/systemd/system/

echo "Enabling startup service"
systemctl enable startup.service
sleep 5
echo "Starting startup service"
systemctl start startup.service
sleep 5
#echo "Going to restart"
#init 6



